create definer = root@localhost trigger add_user_point
    after insert
    on f_reply
    for each row
BEGIN
	update F_user set U_point=U_point+1
	where new.R_uID=F_user.U_id;
END;

