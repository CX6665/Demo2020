create definer = root@localhost trigger add_topic
    after insert
    on f_topic
    for each row
BEGIN
	update F_session set S_topicCount=S_topicCount+1
	where new.T_sID=F_session.S_id;
END;

