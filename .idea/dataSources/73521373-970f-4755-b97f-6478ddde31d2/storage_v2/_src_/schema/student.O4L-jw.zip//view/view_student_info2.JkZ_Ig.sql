create definer = root@localhost view view_student_info2 as
select `s1`.`stu_name2`        AS `stu_name2`,
       `s1`.`stu_no1`          AS `stu_no1`,
       `s1`.`java`             AS `java`,
       `s1`.`mysql`            AS `mysql`,
       `student`.`grade`.`avg` AS `avg`
from `student`.`student_info2` `s1`
         join `student`.`grade`
where (`s1`.`stu_no1` = `student`.`grade`.`stu_no4`)
order by `student`.`grade`.`avg` desc;

